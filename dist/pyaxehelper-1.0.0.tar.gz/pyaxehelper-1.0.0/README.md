# pyaXeHelper

This package contains functions helping pyaXe.

Functions include:

    - change_catalog_order()
    
    - change_magiso2magwavelength()
    
    - write_catalog()
    
    - read_catalog()
    
    - select_source()
    
Known issues:
    
    - ?
    
v.1.0.0

    - Implement: change_catalog_order, change_magiso2magwavelength, write_catalog, read_catalog, select_source
    